﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMSEntities;
using HMSException;
using HMSBAL;
using System.Data;

namespace HMSPL_Phase2
{
    /// <summary>
    /// Interaction logic for InPatientWPF.xaml
    /// </summary>
    public partial class InPatientWPF : Window
    {
        public InPatientWPF()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            InPatient newInPatient = new InPatient();
            try
            {
                newInPatient.PatientId = pId.Text;
                newInPatient.RoomNo = roomId.Text;
                newInPatient.DoctorId = docId.Text;
                newInPatient.AdmissionDate = Convert.ToDateTime(txtadmdate.Text);
                newInPatient.DischargeDate = Convert.ToDateTime(txtdisdate.Text);
                newInPatient.LabId = txtlabid.Text;
                newInPatient.Amount = Convert.ToInt32(txtamt.Text);
                bool inPatientInserted = Hospital_Bal.AddInPatientBAL(newInPatient);
                if (inPatientInserted == true)
                {
                    MessageBox.Show("Patient Record is added..!");
                    RefreshInPatient();
                    Clear();
                }
                else
                    throw new Hospital_Exceptions("Patient record not added..!");
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            InPatient UpdateInPatient = new InPatient();
            try
            {
                UpdateInPatient.PatientId = pId.Text;
                UpdateInPatient.RoomNo = roomId.Text;
                UpdateInPatient.DoctorId = docId.Text;
                UpdateInPatient.AdmissionDate = Convert.ToDateTime(txtadmdate.Text);
                UpdateInPatient.DischargeDate = Convert.ToDateTime(txtdisdate.Text);
                UpdateInPatient.LabId = txtlabid.Text;
                UpdateInPatient.Amount = Convert.ToInt32(txtamt.Text);
                bool updatedInPatientInserted = Hospital_Bal.UpdateInPatientBAL(UpdateInPatient);
                if (updatedInPatientInserted==true)
                {
                    MessageBox.Show("InPatient's Detail Updated Successfully...!");
                    RefreshInPatient();
                    Clear();
                }
                else
                {
                    throw new Hospital_Exceptions("InPatient's Details Not Updated..!");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                InPatient inPatient = null;
                if (pId.Text == null)
                    MessageBox.Show("Enter the InPatient Id to Search..!");
                string pid = pId.Text;
                inPatient = Hospital_Bal.SearchInPatientBAL(pid);
                if (inPatient != null)
                {
                    pId.Text = inPatient.PatientId;
                    pId.IsEnabled = false;
                    roomId.Text = inPatient.RoomNo;
                    docId.Text = inPatient.DoctorId;
                    txtadmdate.Text = Convert.ToDateTime(inPatient.AdmissionDate).ToString();
                    txtdisdate.Text = Convert.ToDateTime(inPatient.DischargeDate).ToString();
                    txtlabid.Text = inPatient.LabId;
                    txtamt.Text = Convert.ToInt32(inPatient.Amount).ToString();
                }
                else
                {
                    throw new Hospital_Exceptions("InPatient's Detail Is Not Available");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string PatientId;
                //
                bool InpatientDeleted;
                //
                PatientId = pId.Text;
                //
                InpatientDeleted = Hospital_Bal.DeleteInPatientBAL(PatientId);
                if (InpatientDeleted == true)
                {
                    MessageBox.Show("Employee record deleted successfully.");
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be deleted.");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //private void BtnSearchDoctor_Click(object sender, RoutedEventArgs e)
        //{
        //    RefreshInPatient();
        //    string docid = docId.SelectedValue.ToString();
        //    try
        //    {
        //        if (docId.Text == "Select")
        //            MessageBox.Show("Enter Doctor Id to Search");
        //        DataSet dataSet = Hospital_Bal.SearchInPatientByDoctorBAL(docid);
        //        dgInPatient.DataContext = dataSet.Tables["InPatient"];

        //    }
        //    catch (Hospital_Exceptions ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}


        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            pId.Text = "";
            roomId.Text = "Select";
            docId.Text = "Select";
            txtadmdate.Text = "";
            txtdisdate.Text = "";
            txtlabid.Text = "Select";
            txtamt.Text = "";
        }


        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Hide();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            Clear();
            RefreshInPatient();
            pId.IsEnabled = true;
        }


        //private void BtnSearchRoom_Click(object sender, RoutedEventArgs e)
        //{
        //    RefreshInPatient();
        //    string roomid = roomId.SelectedValue.ToString();
        //    try
        //    {
        //        if (roomId.Text == "Select")
        //            MessageBox.Show("Enter Room Id to Search");
        //        DataSet dataSet = Hospital_Bal.SearchInPatientByRoomBAL(roomid);
        //        dgInPatient.DataContext = dataSet.Tables["InPatient"];

        //    }
        //    catch (Hospital_Exceptions ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}



        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            RefreshInPatient();
            GetDoctorIds();
            GetLabIds();
            GetRoomIds();
        }
        
        private void GetDoctorIds()
        {
            try
            {                           
            List<string> listofids = Hospital_Bal.GetDoctorIdsBAL();
            docId.ItemsSource = listofids.;
            docId.Text = "Select";
        }

        private void GetLabIds()
        {
            List<string> listofids = Hospital_Bal.GetLabIdsBAL();
            txtlabid.ItemsSource = listofids;
            txtlabid.Text = "Select";
        }

        private void GetRoomIds()
        {
            List<string> listofids = Hospital_Bal.GetRoomIdsBAL();
            roomId.ItemsSource = listofids;
            roomId.Text = "Select";
        }

        private void RefreshInPatient()
        {
            DataTable dtInPatient = Hospital_Bal.GetAllInPatientsBAL();
            if (dtInPatient.Rows.Count > 0)
            {
                dgInPatient.DataContext = dtInPatient;
            }
            else
            {
                MessageBox.Show("No InPatient Details available");
            }
        }

    
        private void Clear()
        {
            pId.Text = "";
            roomId.Text = "Select";
            docId.Text = "Select";
            txtadmdate.Text = "";
            txtdisdate.Text = "";
            txtlabid.Text = "Select";
            txtamt.Text = "";
        }

    }
}
