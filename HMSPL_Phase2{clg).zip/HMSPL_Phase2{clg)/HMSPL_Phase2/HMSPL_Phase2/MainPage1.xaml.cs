﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HMSPL_Phase2
{
    /// <summary>
    /// Interaction logic for MainPage1.xaml
    /// </summary>
    public partial class MainPage1 : Window
    {
        public MainPage1()
        {
            InitializeComponent();
        }

        private void BtnPatient_Click(object sender, RoutedEventArgs e)
        {
            PatientWPF patient = new PatientWPF();
            patient.Show();
            this.Hide();

        }

        private void BtnLab_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnBill_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnInPatient_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnOutPatient_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
