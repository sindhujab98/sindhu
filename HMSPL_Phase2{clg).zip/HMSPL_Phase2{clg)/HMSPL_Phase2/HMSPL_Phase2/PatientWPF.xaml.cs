﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMSEntities;
using HMSException;
using HMSBAL;

namespace HMSPL_Phase2
{
    /// <summary>
    /// Interaction logic for PatientWPF.xaml
    /// </summary>
    public partial class PatientWPF : Window
    {
        Hospital_Bal bal = null;
        public PatientWPF()
        {
            InitializeComponent();
            bal = new Hospital_Bal();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Patient objPatient = new Patient();
                if (txtPatientId.Text == string.Empty || txtDoctorId.Text == string.Empty || txtPatientName.Text == string.Empty || txtPhoneNo.Text == string.Empty ||
                    txtGender.Text == string.Empty || txtAge.Text == string.Empty || txtPWeight.Text == string.Empty || txtPAddress.Text == string.Empty || txtDisease.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool RecordAdded;
                    objPatient.PatientId = txtPatientId.Text;
                    objPatient.DoctorId = txtDoctorId.Text;
                    objPatient.PatientName = txtPatientName.Text;
                    objPatient.PhoneNo = txtPhoneNo.Text;
                    objPatient.Gender = txtGender.Text.ToString();
                    objPatient.Age = int.Parse(txtAge.Text);
                    objPatient.PWeight = float.Parse(txtPWeight.Text);
                    objPatient.PAddress = txtPAddress.Text;
                    objPatient.Disease = txtDisease.Text;

                    RecordAdded = Hospital_Bal.AddPatientBAL(objPatient);
                    if (RecordAdded == true)
                    {
                        MessageBox.Show("Patient record added successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be added.");
                    }
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
   
    private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Patient objPatient = new Patient();
                if (txtPatientId.Text == string.Empty || txtDoctorId.Text == string.Empty || txtPatientName.Text == string.Empty || txtPhoneNo.Text == string.Empty ||
                    txtGender.Text == string.Empty || txtAge.Text == string.Empty || txtPWeight.Text == string.Empty || txtPAddress.Text == string.Empty || txtDisease.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool RecordUpdated;

                    objPatient.PatientId = txtPatientId.Text;
                    objPatient.DoctorId = txtDoctorId.Text;
                    objPatient.PatientName = txtPatientName.Text;
                    objPatient.PhoneNo = txtPhoneNo.Text;
                    objPatient.Gender = txtGender.Text;
                    objPatient.Age = int.Parse(txtAge.Text);
                    objPatient.PWeight = double.Parse(txtPWeight.Text);
                    objPatient.PAddress = txtPAddress.Text;
                    objPatient.Disease = txtDisease.Text;

                    RecordUpdated = Hospital_Bal.UpdatePatientBAL(objPatient);
                    if (RecordUpdated == true)
                    {
                        MessageBox.Show("Patient record updated successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be updated.");
                    }
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    
     private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string PatientId;
                //
                bool patientDeleted;
                //
                PatientId = txtPatientId.Text;
                //
                patientDeleted = Hospital_Bal.DeletePatientBAL(PatientId);
                if (patientDeleted == true)
                {
                    MessageBox.Show("Patient record deleted successfully.");
                }
                else
                {
                    MessageBox.Show("Patient record couldn't be deleted.");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    

        private void BtnSearchByID_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string PatientId;
                Patient objPatient;
                PatientId = txtPatientId.Text;
                objPatient = Hospital_Bal.SearchPatientbyPatientIDBAL(PatientId);
                if (objPatient != null)
                {
                    txtDoctorId.Text = objPatient.DoctorId;
                    txtPatientName.Text = objPatient.PatientName;
                    txtPhoneNo.Text = objPatient.PhoneNo;
                    txtGender.Text = objPatient.Gender;
                    txtAge.Text = Convert.ToInt32(objPatient.Age).ToString();
                    txtPWeight.Text = Convert.ToDouble(objPatient.PWeight).ToString();
                    txtPAddress.Text = objPatient.PAddress;
                    txtDisease.Text = objPatient.Disease;
                }

                else
                {
                    MessageBox.Show("Patient record couldn't be found.");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    private void BtnSearchByDoctor_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnPatient_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                List<Patient> objpatients = Hospital_Bal.GetAllPatientBAL();
                if (objpatients != null)
                {
                    dgPatients.ItemsSource = objpatients;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (Hospital_Exceptions ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            txtPatientId.Clear();
            txtDoctorId.Clear();
            txtPatientName.Clear();
            txtPhoneNo.Clear();
            txtGender.SelectedIndex = -1;
            txtAge.Clear();
            txtPWeight.Clear();
            txtPAddress.Clear();
            txtDisease.Clear();
            dgPatients.DataContext = null;
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            MainPage1 window = new MainPage1();
            window.Show();
            this.Hide();
        }
    }
}
