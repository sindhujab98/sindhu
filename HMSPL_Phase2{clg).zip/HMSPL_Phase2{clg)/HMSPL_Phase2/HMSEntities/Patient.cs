﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSEntities
{
   public class Patient
    {
        public string PatientId { get; set; }
        public string DoctorId { get; set; }
        public string PatientName { get; set; }
        public string PhoneNo { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
        public string PAddress { get; set; }
        public double PWeight { get; set; }
        public string Disease { get; set; }
    }
}
