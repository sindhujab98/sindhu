﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using HMSDAL;
using HMSEntities;
using HMSException;


namespace HMSBAL
{
    public class Hospital_Bal
    {
        private static bool ValidatePatient(Patient patient)
        {
            StringBuilder sb = new StringBuilder();
            bool validPatient = true;
            if (patient.PatientId == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine
                    + "Patient can't  be empty");
            }
            if (patient.DoctorId == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "DoctorID  can't be empty.");
            }
            if (patient.PatientName == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Patient name should start with Capital.");
            }
            if (patient.PhoneNo.Length < 0)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Mobile number must be of 10 digits.");
            }
            else if (!Regex.IsMatch(patient.PhoneNo, "[6-9][0-9]{9}"))
            {
                sb.Append("Phone number should start with 6 or 7 or 8 or 9 and it should have exactly 10 digits\n");
                validPatient = false;
            }
            if (validPatient == false)
            {
                throw new Hospital_Exceptions(sb.ToString());
            }
            return validPatient;

        }

        private static bool ValidateAppointment(Appointment appointment)
        {
            StringBuilder sb = new StringBuilder();
            bool validAppointment = true;
            try
            {
                if (appointment.AppointmentId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Appointment Id is required cannnot be blank");
                    validAppointment = false;
                }
                if (appointment.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validAppointment = false;
                }
                if (validAppointment == false)
                    throw new Hospital_Exceptions(sb.ToString());
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validAppointment;
        }

        private static bool ValidateBill(BillGeneration bill)
        {
            StringBuilder sb = new StringBuilder();
            bool validBill = true;
            try
            {
                if (bill.BillId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Bill Id is required cannnot be blank");
                    validBill = false;
                }
                if (bill.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validBill = false;
                }
                else if (bill.PatientId == "Select")
                {
                    sb.Append(Environment.NewLine + "Patient Id is required");
                    validBill = false;
                }
                if (bill.DoctorId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                    validBill = false;
                }
                else if (bill.DoctorId == "Select")
                {
                    sb.Append(Environment.NewLine + "Doctor Id is Required");
                    validBill = false;
                }
                if (validBill == false)
                    throw new Hospital_Exceptions(sb.ToString());
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validBill;
        }

        private static bool ValidateLab(LabReport lab)
        {
            StringBuilder sb = new StringBuilder();
            bool validLab = true;
            try
            {
                if (lab.LabId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Lab Id is required cannnot be blank");
                    validLab = false;
                }
                if (lab.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validLab = false;
                }
                else if (lab.PatientId == "Select")
                {
                    sb.Append(Environment.NewLine + "Patient Id is Required");
                    validLab = false;
                }
                if (lab.DoctorId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                    validLab = false;
                }
                if (validLab == false)
                    throw new Hospital_Exceptions(sb.ToString());
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validLab;
        }

        private static bool ValidateInPatient(InPatient inPatient)
        {
            StringBuilder sb = new StringBuilder();
            bool validInPatient = true;
            try
            {
                if (inPatient.LabId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Lab Id is required cannnot be blank");
                    validInPatient = false;
                }
                else if (inPatient.LabId == "Select")
                {
                    sb.Append(Environment.NewLine + "Lab Id is Required");
                    validInPatient = false;
                }
                if (inPatient.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validInPatient = false;
                }
                if (inPatient.RoomNo == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Room Id is required cannnot be blank");
                    validInPatient = false;
                }

                else if (inPatient.RoomNo == "Select")
                {
                    sb.Append(Environment.NewLine + "Room Id is Required");
                    validInPatient = false;
                }
                if (inPatient.DoctorId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                    validInPatient = false;
                }
                else if (inPatient.DoctorId == "Select")
                {
                    sb.Append(Environment.NewLine + "Doctor Id is Required");
                    validInPatient = false;
                }
                if (inPatient.AdmissionDate == null)
                {
                    sb.Append(Environment.NewLine + "Admission Date is Required");
                    validInPatient = false;
                }
                if (inPatient.DischargeDate == null)
                {
                    sb.Append(Environment.NewLine + "Discharge Date is Required");
                    validInPatient = false;
                }
                if (inPatient.Amount <= 0)
                {
                    sb.Append(Environment.NewLine + "Enter the Amount Per Day");
                    validInPatient = false;
                }
                if (validInPatient == false)
                    throw new Hospital_Exceptions(sb.ToString());
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validInPatient;
        }

        public static DataSet SearchInPatientByDoctorBAL(string docid)
        {
            throw new NotImplementedException();
        }

        private static bool ValidateOutPatient(OutPatient outPatient)
        {
            StringBuilder sb = new StringBuilder();
            bool validOutPatient = true;
            try
            {
                if (outPatient.LabId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Lab Id is required cannnot be blank");
                    validOutPatient = false;
                }
                else if (outPatient.LabId == "Select")
                {
                    sb.Append(Environment.NewLine + "Lab Id is Required");
                    validOutPatient = false;
                }
                if (outPatient.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validOutPatient = false;
                }
                if (outPatient.DoctorId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                    validOutPatient = false;
                }
                else if (outPatient.DoctorId == "Select")
                {
                    sb.Append(Environment.NewLine + "Doctor Id is Required");
                    validOutPatient = false;
                }
                if (outPatient.TreatmentDate == null)
                {
                    sb.Append(Environment.NewLine + "Treatment Date is Required");
                    validOutPatient = false;
                }
                if (validOutPatient == false)
                    throw new Hospital_Exceptions(sb.ToString());
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validOutPatient;
        }

        public static bool AddPatientBAL(Patient patient)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(patient))
                {
                    Hospital_Dal patientDAL = new Hospital_Dal();
                    patientAdded = patientDAL.AddPatientDAL(patient);
                    return patientAdded;
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        public static bool UpdatePatientBAL(Patient patient)
        {
            bool patientUpdated = false;
            try
            {
                if (ValidatePatient(patient))
                {
                    Hospital_Dal patientDAL = new Hospital_Dal();
                    patientUpdated = patientDAL.UpdatePatientDAL(patient);
                    return patientUpdated;
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientUpdated;
        }

        public static bool DeletePatientBAL(string PatientId)
        {

            bool PatientDeleted = false;
            try
            {
                if (PatientId != null)
                {
                    Hospital_Dal patientDAL = new Hospital_Dal();

                    PatientDeleted = patientDAL.DeletePatientDAL(PatientId);
                }
                else
                {
                    throw new Hospital_Exceptions("Invalid OutPatient ID");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return PatientDeleted;
        }

        public static Patient SearchPatientbyPatientIDBAL(string patientId)
        {
            Patient patient = null;
            try
            {
                if (patientId != null)
                {
                    Hospital_Dal patientDAL = new Hospital_Dal();
                    patient = patientDAL.SearchPatientbyPatientIdDAL(patientId);
                }
                else
                {
                    throw new Hospital_Exceptions("Patient Id is Required.");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patient;
        }

        public static List<Patient> GetAllPatientBAL()
        {
            List<Patient> patientList;
            try
            {
                Hospital_Dal patient = new Hospital_Dal();
                patientList = patient.GetAllPatientsDAL();
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientList;
        }








        //List details


        public static List<string> GetDoctorIdsBAL()
        {
            List<string> listObj = null;
            try
            {
                listObj = Hospital_Dal.GetDoctorIdsDAL();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listObj;
        }

        public static List<string> GetPatientIds()
        {
            List<string> listObj = null;
            try
            {
                listObj = Hospital_Dal.GetPatientIdsDAL();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listObj;
        }

        public static List<string> GetLabIdsBAL()
        {
            List<string> listObj = null;
            try
            {
                listObj = Hospital_Dal.GetLabIdsDAL();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listObj;
        }

        public static List<string> GetRoomIdsBAL()
        {
            List<string> listObj = null;
            try
            {
                listObj = Hospital_Dal.GetRoomIdsDAL();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listObj;
        }

    
      //InPatient Information

        public static bool AddInPatientBAL(InPatient newInPatient)
        {
            bool InpatientAdded = false;
            try
            {
                if (ValidateInPatient(newInPatient))
                {
                    Hospital_Dal inpatientDAL=new Hospital_Dal();
                    InpatientAdded = inpatientDAL.AddInPatientDAL(newInPatient);

                    return InpatientAdded;
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return InpatientAdded;
        
    }

        public static bool UpdateInPatientBAL(InPatient UpdateInPatient)
        {
            bool InpatientUpdated = false;
            try
            {
                if (ValidateInPatient(UpdateInPatient))
                {
                    Hospital_Dal inPatientUpdateDAL = new Hospital_Dal();
                    InpatientUpdated = inPatientUpdateDAL.UpdateInPatientDAL(UpdateInPatient);
                    return InpatientUpdated;
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return InpatientUpdated;
        }


        public static InPatient SearchInPatientBAL(string searchInPatientID)
        {
            InPatient searchInPatient = null;
            try
            {
                if (searchInPatientID!= null)
                {
                    Hospital_Dal searchInPatientDAL = new Hospital_Dal();
                    searchInPatient = searchInPatientDAL.SearchInPatientDAL(searchInPatientID);
                }
                else
                {
                    throw new Hospital_Exceptions("Employee Id must be greater than 0.");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchInPatient;
        }

        public static bool DeleteInPatientBAL(string deleteInPatientID)
        {
            bool InpatientDeleted = false;
            try
            {
                if (deleteInPatientID !=null)
                {
                    Hospital_Dal InpatientDal = new Hospital_Dal();
                    InpatientDeleted = InpatientDal.DeleteInPatientDAL(deleteInPatientID);
                }
                else
                {
                    throw new Hospital_Exceptions("Employee Id must be greater than 0.");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return InpatientDeleted;
        }

        public static DataTable GetAllInPatientsBAL()
        {
            DataTable dtInPatient = null;
            try
            {
                dtInPatient = Hospital_Dal.GetAllInPatientsDAL();
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtInPatient;
        }
    }
}





    