﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMSBAL;
using HMSEntities;
using HMSException;


namespace HMSPL_Phase2
{
    /// <summary>
    /// Interaction logic for LabWPF.xaml
    /// </summary>
    public partial class LabWPF : Window
    {
        public LabWPF()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                LabReport lab = new LabReport();
                if (txtLabId.Text == string.Empty || txtPatientId.Text == string.Empty ||
                    txtDoctorId.Text == string.Empty || 
                    txttestdate.Text == string.Empty || txtTestType.Text == string.Empty || 
                    txtPatientType.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool LabAdded;
                    lab.LabId = txtLabId.Text;
                    lab.PatientId = txtPatientId.Text;
                    lab.DoctorId = txtDoctorId.Text;
                    lab.TestDate = Convert.ToDateTime(txttestdate.Text);
                    lab.TestType = txtTestType.Text;
                    lab.PatientType = txtPatientType.Text;
                    LabAdded = Hospital_Bal.AddLabBAL(lab);
                    if (LabAdded == true)
                    {
                        MessageBox.Show("Lab Added successfully");
                    }
                    else
                    {
                        MessageBox.Show("Lab couldn't be Added ");
                    }
                }

            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                LabReport lab = new LabReport();
                if (txtLabId.Text == string.Empty || txtPatientId.Text == string.Empty || 
                    txtDoctorId.Text == string.Empty || txttestdate.Text == string.Empty || 
                    txtTestType.Text == string.Empty || txtPatientType.Text == string.Empty)
               
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool LabUpadted;
                    lab.LabId = txtLabId.Text;
                    lab.PatientId = txtPatientId.Text;
                    lab.DoctorId = txtDoctorId.Text;
                    lab.TestDate = Convert.ToDateTime(txttestdate.Text);
                    lab.TestType = txtTestType.Text;
                    lab.PatientType = txtPatientType.Text;
                    LabUpadted = Hospital_Bal.AddLabBAL(lab);
                    if (LabUpadted == true)
                    {
                        MessageBox.Show("Lab Upadted successfully");
                    }
                    else
                    {
                        MessageBox.Show("Lab couldn't be  updated");
                    }
                }

            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            string patientId;
            LabReport lab = new LabReport();
            try
            {

                if (txtPatientId.Text == string.Empty)
                {
                    MessageBox.Show("ID is Required");
                }
                else
                {
                    bool patientDeleted;
                    //
                    patientId = txtPatientId.Text;
                    //
                    patientDeleted = Hospital_Bal.DeleteLabBAL(patientId);
                    if (patientDeleted == true)
                    {
                        MessageBox.Show("Patient record deleted successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be deleted.");
                    }
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearchByID_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string PatientId;
                LabReport objPatient;
                PatientId = txtPatientId.Text;
                objPatient = Hospital_Bal.SearchLabBAL(PatientId);
                if (objPatient != null)
                {
                    txtLabId.Text = objPatient.LabId;
                    txtDoctorId.Text = objPatient.DoctorId;                   
                    txttestdate.Text = Convert.ToDateTime(objPatient.TestDate).ToString();
                    txtTestType.Text = objPatient.TestType;
                    txtPatientType.Text = objPatient.PatientType;
                }

                else
                {
                    MessageBox.Show("Patient record couldn't be found.");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnLab_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                List<LabReport> objLabs = Hospital_Bal.GetAllLabsBAL();
                if (objLabs != null)
                {
                    dgLab.ItemsSource = objLabs;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (Hospital_Exceptions ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.Show();
            this.Hide();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
       
            GetDoctor();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            Clear();
            RefreshLab();

        }
        public void Clear()
        {
            txtPatientId.Clear();
            txttestdate.Text = "";
            txtDoctorId.SelectedValue = -1;
            txtLabId.Clear();
            txtTestType.Clear();
            txtPatientType.Clear();

        }
        private void GetDoctor()
        {
            try
            {
                DataTable doctorList = Hospital_Bal.GetDoctorBAL();
                txtDoctorId.ItemsSource = doctorList.DefaultView;
                txtDoctorId.DisplayMemberPath = doctorList.Columns[0].ColumnName;
                txtDoctorId.SelectedValuePath = doctorList.Columns[0].ColumnName;
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
       
        private void RefreshLab()
        {
            List<LabReport> labs = null;
            labs = Hospital_Bal.GetAllLabsBAL();
            if (labs.Count > 0)
            {
                dgLab.DataContext = labs;
            }
            else
            {
                MessageBox.Show("No Lab Details available");
            }
        }


    }
}
