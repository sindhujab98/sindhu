﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMSEntities;
using HMSException;
using HMSBAL;
using System.Data;

namespace HMSPL_Phase2
{
    /// <summary>
    /// Interaction logic for InPatientWPF.xaml
    /// </summary>
    public partial class InPatientWPF : Window
    {
        public InPatientWPF()
        {
            InitializeComponent();
        }
        
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDoctor();
            GetLab();
            GetRoom();
           
        }

        private void GetDoctor()
        {
            try
            {
                DataTable doctorList = Hospital_Bal.GetDoctorBAL();
                docId.ItemsSource = doctorList.DefaultView;
                docId.DisplayMemberPath = doctorList.Columns[0].ColumnName;
                docId.SelectedValuePath = doctorList.Columns[0].ColumnName;
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetLab()
        {
            try
            {
                DataTable labList = Hospital_Bal.GetLabBAL();
                txtlabid.ItemsSource = labList.DefaultView;
                txtlabid.DisplayMemberPath = labList.Columns[0].ColumnName;
                txtlabid.SelectedValuePath = labList.Columns[0].ColumnName;
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetRoom()
        {
            try
            {
                DataTable roomList = Hospital_Bal.GetRoomBAL();
                roomId.ItemsSource = roomList.DefaultView;
                roomId.DisplayMemberPath = roomList.Columns[0].ColumnName;
                roomId.SelectedValuePath = roomList.Columns[0].ColumnName;
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Clear()
        {
            pId.Text = "";
            roomId.Text = "Select";
            docId.Text = "Select";
            txtadmdate.Text = "";
            txtdisdate.Text = "";
            txtlabid.Text = "Select";
            txtamt.Text = "";
        }
    
        private void BtnAdd_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                InPatient newInPatient = new InPatient();
                if (pId.Text == string.Empty || roomId.Text == string.Empty || docId.Text == string.Empty || txtadmdate.Text == string.Empty || txtdisdate.Text == string.Empty ||
                   txtlabid.Text == string.Empty || txtamt.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    newInPatient.PatientId = pId.Text;
                    newInPatient.RoomNo = roomId.Text;
                    newInPatient.DoctorId = docId.Text;
                    newInPatient.AdmissionDate = Convert.ToDateTime(txtadmdate.Text);
                    newInPatient.DischargeDate = Convert.ToDateTime(txtdisdate.Text);
                    newInPatient.LabId = txtlabid.Text;
                    newInPatient.Amount = Convert.ToInt32(txtamt.Text);
                    bool inPatientInserted = Hospital_Bal.AddInPatientBAL(newInPatient);
                    if (inPatientInserted == true)
                    {
                        MessageBox.Show("Patient Record is added..!");
                        //RefreshInPatient();
                        //Clear();
                    }
                    else
                        throw new Hospital_Exceptions("Patient record not added..!");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                InPatient UpdateInPatient = new InPatient();
                if (pId.Text == string.Empty || roomId.Text == string.Empty || docId.Text == string.Empty || txtadmdate.Text == string.Empty || txtdisdate.Text == string.Empty ||
                   txtlabid.Text == string.Empty || txtamt.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool updatedInPatient;
                    UpdateInPatient.PatientId = pId.Text;
                    UpdateInPatient.RoomNo = roomId.Text;
                    UpdateInPatient.DoctorId = docId.Text;
                    UpdateInPatient.AdmissionDate = Convert.ToDateTime(txtadmdate.Text);
                    UpdateInPatient.DischargeDate = Convert.ToDateTime(txtdisdate.Text);
                    UpdateInPatient.LabId = txtlabid.Text;
                    UpdateInPatient.Amount = Convert.ToInt32(txtamt.Text);
                    updatedInPatient = Hospital_Bal.UpdateInPatientBAL(UpdateInPatient);
                    if (updatedInPatient == true)
                    {
                        MessageBox.Show("InPatient's Detail Updated Successfully...!");
                        //RefreshInPatient();
                        //Clear();
                    }
                    else
                    {
                        throw new Hospital_Exceptions("InPatient's Details Not Updated..!");
                    }
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click_1(object sender, RoutedEventArgs e)
        {
            string patientId;
            InPatient patient = new InPatient();
            try
            {
                if (pId.Text == string.Empty)
                {
                    MessageBox.Show("ID is Required");
                }
                else
                {
                    bool patientDeleted;
                    //
                    patientId = pId.Text;
                    //
                    patientDeleted = Hospital_Bal.DeleteInPatientBAL(patientId);
                    if (patientDeleted == true)
                    {
                        MessageBox.Show("Patient record deleted successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be deleted.");
                    }
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearchByID_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string patientId;
                InPatient inPatient;
                patientId = pId.Text;
                inPatient = Hospital_Bal.SearchInPatientBAL(patientId);
                if (inPatient != null)
                {

                    //pId.Text = inPatient.PatientId;
                    //pId.IsEnabled = false;
                    roomId.Text = inPatient.RoomNo;
                    docId.Text = inPatient.DoctorId;
                    txtadmdate.Text = Convert.ToDateTime(inPatient.AdmissionDate).ToString();
                    txtdisdate.Text = Convert.ToDateTime(inPatient.DischargeDate).ToString();
                    txtlabid.Text = inPatient.LabId;
                    txtamt.Text = Convert.ToInt32(inPatient.Amount).ToString();
                }
                else
                {
                    throw new Hospital_Exceptions("InPatient's Detail Is Not Available");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnPatient_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                List<InPatient> objpatients = Hospital_Bal.GetAllInPatientBAL();
                if (objpatients != null)
                {
                    dgInPatient.ItemsSource = objpatients;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (Hospital_Exceptions ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        private void BtnClear_Click_1(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        private void BtnBack_Click_1(object sender, RoutedEventArgs e)
        {
            MainPage1 window = new MainPage1();
            window.Show();
            this.Hide();
        }
    }
}
