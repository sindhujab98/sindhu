﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMSEntities;
using HMSException;
using HMSBAL;
using System.Data;

namespace HMSPL_Phase2
{
    /// <summary>
    /// Interaction logic for BillWPF.xaml
    /// </summary>
    public partial class BillWPF : Window
    {
        public BillWPF()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                BillGeneration bill = new BillGeneration();
                if (txtbillId.Text == string.Empty || txtPatientId.Text == string.Empty ||
                    txtPatientType.Text==string.Empty ||txtDoctorId.Text == string.Empty || 
                    txtDoctorFee.Text == string.Empty || txtRoomCharge.Text == string.Empty||                  
                    txtOperationCharges.Text == string.Empty || txtMedicalFee.Text == string.Empty||
                    txtTotalDays.Text==string.Empty || txtLabFees.Text == string.Empty || txtTotalAmount.Text==string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bill.BillId = txtbillId.Text;
                    bill.PatientId = txtPatientId.Text;
                    bill.PatientType = txtPatientType.Text;
                    bill.DoctorId = txtDoctorId.Text;
                    bill.DoctorFees = Convert.ToInt32( txtDoctorFee.Text);
                    bill.RoomCharges = Convert.ToInt32(txtRoomCharge.Text);
                    bill.OperationCharges = Convert.ToInt32(txtOperationCharges.Text);
                    bill.MedicineFees = Convert.ToInt32(txtMedicalFee.Text);
                    bill.TotalDays = Convert.ToInt32(txtTotalDays.Text);
                    bill.TotalAmount = Convert.ToInt32(txtTotalAmount.Text);
                    bool inPatientInserted = Hospital_Bal.AddBillBAL(bill);
                    if (inPatientInserted == true)
                    {
                        MessageBox.Show("Bill is added..!");
                        //RefreshInPatient();
                        //Clear();
                    }
                    else
                        throw new Hospital_Exceptions("Bill is not added..!");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                BillGeneration bill = new BillGeneration();
                if(txtbillId.Text == string.Empty || txtPatientId.Text == string.Empty ||
                     txtPatientType.Text == string.Empty || txtDoctorId.Text == string.Empty ||
                     txtDoctorFee.Text == string.Empty || txtRoomCharge.Text == string.Empty ||
                     txtOperationCharges.Text == string.Empty || txtMedicalFee.Text == string.Empty ||
                     txtTotalDays.Text == string.Empty || txtLabFees.Text == string.Empty || txtTotalAmount.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bill.BillId = txtbillId.Text;
                    bill.PatientId = txtPatientId.Text;
                    bill.PatientType = txtPatientType.Text;
                    bill.DoctorId = txtDoctorId.Text;
                    bill.DoctorFees = Convert.ToInt32(txtDoctorFee.Text);
                    bill.RoomCharges = Convert.ToInt32(txtRoomCharge.Text);
                    bill.OperationCharges = Convert.ToInt32(txtOperationCharges.Text);
                    bill.MedicineFees = Convert.ToInt32(txtMedicalFee.Text);
                    bill.TotalDays = Convert.ToInt32(txtTotalDays.Text);
                    bill.TotalAmount = Convert.ToInt32(txtTotalAmount.Text);
                    bool billUpdated= Hospital_Bal.AddBillBAL(bill); ;
           
                    if (billUpdated == true)
                    {
                        MessageBox.Show("Bill updated successfully");
                    }
                    else
                    {
                        MessageBox.Show("InPatient couldn't be updated");
                    }
                }

            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            string billId;
            BillGeneration patient = new BillGeneration();
            try
            {

                if (txtbillId.Text == string.Empty)
                {
                    MessageBox.Show("ID is Required");
                }
                else
                {
                    bool billDeleted;
                    //
                    billId = txtbillId.Text;
                    //
                    billDeleted = Hospital_Bal.DeleteBillBAL(billId);
                    if (billDeleted == true)
                    {
                        MessageBox.Show("Bill record deleted successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Bill record couldn't be deleted.");
                    }
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearchByBill_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                string BillId;
                BillGeneration objBill;
                BillId = txtbillId.Text;
                objBill = Hospital_Bal.SearchBillBAL(BillId);
                if (objBill != null)
                {
                    txtPatientId.Text = objBill.PatientId;
                    txtPatientType.Text = objBill.PatientType;
                    txtDoctorId.Text = objBill.DoctorId;
                    txtDoctorFee.Text = Convert.ToDouble(objBill.DoctorFees).ToString();
                    txtRoomCharge.Text = Convert.ToDouble(objBill.RoomCharges).ToString();
                    txtOperationCharges.Text = Convert.ToDouble(objBill.OperationCharges).ToString();
                    txtMedicalFee.Text = Convert.ToDouble(objBill.MedicineFees).ToString();
                    txtTotalDays.Text = Convert.ToInt32(objBill.TotalDays).ToString();
                    txtLabFees.Text = Convert.ToDouble(objBill.LabFees).ToString();
                    txtTotalAmount.Text = Convert.ToDouble(objBill.TotalAmount).ToString();

                }

                else
                {
                    MessageBox.Show("Bill record couldn't be found.");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {

            MainPage1 window = new MainPage1();
            window.Show();
            this.Hide();
        }
        //private void RefreshInPatient()
        //{
        //    List<BillGeneration> bills = null;
        //    bills = Hospital_Bal.GetAllBillSBAL();
        //    if (bills.Count > 0)
        //    {
        //        dgBill.DataContext = bills;
        //    }
        //    else
        //    {
        //        MessageBox.Show("No InPatient Details available");
        //    }
        //}
        public void Clear()
        {
            txtbillId.Clear();
            txtPatientId.SelectedValue = -1;
            txtPatientType.Clear();
            txtDoctorId.SelectedValue = -1;
            txtDoctorFee.Clear();
            txtRoomCharge.Clear();
            txtLabFees.Clear();
            txtOperationCharges.Clear();
            txtMedicalFee.Clear();
            txtTotalDays.Clear();
            txtTotalAmount.Clear();

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDoctor();
            GetPatient();
        }
        private void GetDoctor()
        {
            try
            {
                DataTable doctorList = Hospital_Bal.GetDoctorBAL();
                txtDoctorId.ItemsSource = doctorList.DefaultView;
                txtDoctorId.DisplayMemberPath = doctorList.Columns[0].ColumnName;
                txtDoctorId.SelectedValuePath = doctorList.Columns[0].ColumnName;
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetPatient()
        {
            try
            {
                DataTable patientList = Hospital_Bal.GetPatientBAL();
                txtPatientId.ItemsSource = patientList.DefaultView;
                txtPatientId.DisplayMemberPath = patientList.Columns[0].ColumnName;
                txtPatientId.SelectedValuePath = patientList.Columns[0].ColumnName;
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
