﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMSBAL;
using HMSEntities;
using HMSException;

namespace HMSPL_Phase2
{
    /// <summary>
    /// Interaction logic for OutPatient.xaml
    /// </summary>
    public partial class OutPatientWPF : Window
    {
        public OutPatientWPF()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OutPatient newOutPatient = new OutPatient();
                if (pId.Text == string.Empty || docId.Text == string.Empty || txttreatmentdate.Text == string.Empty || labid.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    newOutPatient.PatientId = pId.Text;
                    newOutPatient.DoctorId = docId.Text;
                    newOutPatient.TreatmentDate = Convert.ToDateTime(txttreatmentdate.Text);
                    newOutPatient.LabId = labid.Text;

                    bool outPatientInserted = Hospital_Bal.AddOutPatientBAL(newOutPatient);
                    if (outPatientInserted == true)
                    {
                        MessageBox.Show("Patient Record is added..!");
                        RefreshOutPatient();
                        Clear();
                    }
                    else
                        throw new Hospital_Exceptions("Patient record not added..!");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OutPatient UpdateOutPatient = new OutPatient();
                if (pId.Text == string.Empty || txttreatmentdate.Text == string.Empty || docId.Text == string.Empty || labid.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    UpdateOutPatient.PatientId = pId.Text;
                    UpdateOutPatient.TreatmentDate = Convert.ToDateTime(txttreatmentdate.Text);
                    UpdateOutPatient.DoctorId = docId.Text;
                    UpdateOutPatient.LabId = labid.Text;

                    bool updatedOutPatientInserted = Hospital_Bal.UpdateOutPatientBAL(UpdateOutPatient);
                    if (updatedOutPatientInserted == true)
                    {
                        MessageBox.Show("InPatient's Detail Updated Successfully...!");
                        RefreshOutPatient();
                        Clear();
                    }
                    else
                    {
                        throw new Hospital_Exceptions("InPatient's Details Not Updated..!");
                    }
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string patientId;
                OutPatient outPatient;
                patientId = pId.Text;
                outPatient = Hospital_Bal.SearchOutPatientBAL(patientId);
                if (outPatient != null)
                {
                    
                    //pId.Text = outPatient.PatientId;
                    //pId.IsEnabled = false;
                    txttreatmentdate.Text = Convert.ToDateTime(outPatient.TreatmentDate).ToString();
                    docId.Text = outPatient.DoctorId;
                    labid.Text = outPatient.LabId;
                }
                else
                {
                    throw new Hospital_Exceptions("InPatient's Detail Is Not Available");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {

            string patientId;
            OutPatient patient = new OutPatient();
            try
            {
                if (pId.Text == string.Empty)
                {
                    MessageBox.Show("ID is Required");
                }
                else
                {
                    bool patientDeleted;
                    //
                    patientId = pId.Text;
                    //
                    patientDeleted = Hospital_Bal.DeleteOutPatientBAL(patientId);
                    if (patientDeleted == true)
                    {
                        MessageBox.Show("Patient record deleted successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be deleted.");
                    }
                }
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

       
        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            MainPage1 window = new MainPage1();
            window.Show();
            this.Hide();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            Clear();
            RefreshOutPatient();
        }



        //private void BtnSearchDoctor_Click(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        OutPatient inPatient = null;
        //        if (pId.Text == null)
        //            MessageBox.Show("Enter the InPatient Id to Search..!");
        //        string pid = pId.Text;
        //        inPatient = Hospital_Bal.SearchOutPatientBAL(pid);
        //        if (inPatient != null)
        //        {
        //            pId.Text = inPatient.PatientId;
        //            pId.IsEnabled = false;
        //            roomId.Text = inPatient.RoomNo;
        //            docId.Text = inPatient.DoctorId;
        //            txtadmdate.Text = Convert.ToDateTime(inPatient.AdmissionDate).ToString();
        //            txtdisdate.Text = Convert.ToDateTime(inPatient.DischargeDate).ToString();
        //            txtlabid.Text = inPatient.LabId;
        //            txtamt.Text = Convert.ToInt32(inPatient.Amount).ToString();
        //        }
        //        else
        //        {
        //            throw new Hospital_Exceptions("InPatient's Detail Is Not Available");
        //        }
        //    }
        //    catch (Hospital_Exceptions ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //}


        //private void BtnSearchLab_Click(object sender, RoutedEventArgs e)
        //{

        //}

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDoctor();
            GetLab();
            //RefreshOutPatient();
        }

        private void GetDoctor()
        {
            try
            {
                DataTable doctorList = Hospital_Bal.GetDoctorBAL();
                docId.ItemsSource = doctorList.DefaultView;
                docId.DisplayMemberPath = doctorList.Columns[0].ColumnName;
                docId.SelectedValuePath = doctorList.Columns[0].ColumnName;
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetLab()
        {
            try
            {
                DataTable labList = Hospital_Bal.GetLabBAL();
                labid.ItemsSource = labList.DefaultView;
                labid.DisplayMemberPath = labList.Columns[0].ColumnName;
                labid.SelectedValuePath = labList.Columns[0].ColumnName;
            }
            catch (Hospital_Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void RefreshOutPatient()
        {
            List<OutPatient> outPatients = null;
            outPatients = Hospital_Bal.GetAllOutPatientBAL();
            if (outPatients.Count > 0)
            {
                dgOutPatient.DataContext = outPatients;
            }
            else
            {
                MessageBox.Show("No InPatient Details available");
            }

        }
        private void Clear()
        {
            pId.Text = "";
            txttreatmentdate.Text = "";
            docId.Text = "Select";                 
           labid.Text = "Select";
            
        }

    }
}
