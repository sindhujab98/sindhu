﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using HMSDAL;
using HMSEntities;
using HMSException;


namespace HMSBAL
{
    public class Hospital_Bal
    {
        private static bool ValidatePatient(Patient patient)
        {
            StringBuilder sb = new StringBuilder();
            bool validPatient = true;
            if (patient.PatientId == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine
                    + "Patient can't  be empty");
            }
            if (patient.DoctorId == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "DoctorID  can't be empty.");
            }
            if (patient.PatientName == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Patient name should start with Capital.");
            }
            if (patient.PhoneNo.Length < 0)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Mobile number must be of 10 digits.");
            }
            else if (!Regex.IsMatch(patient.PhoneNo, "[6-9][0-9]{9}"))
            {
                sb.Append("Phone number should start with 6 or 7 or 8 or 9 and it should have exactly 10 digits\n");
                validPatient = false;
            }
            if (validPatient == false)
            {
                throw new Hospital_Exceptions(sb.ToString());
            }
            return validPatient;

        }

        private static bool ValidateAppointment(Appointment appointment)
        {
            StringBuilder sb = new StringBuilder();
            bool validAppointment = true;
            try
            {
                if (appointment.AppointmentId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Appointment Id is required cannnot be blank");
                    validAppointment = false;
                }
                if (appointment.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validAppointment = false;
                }
                if (validAppointment == false)
                    throw new Hospital_Exceptions(sb.ToString());
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validAppointment;
        }

        private static bool ValidateBill(BillGeneration bill)
        {
            StringBuilder sb = new StringBuilder();
            bool validBill = true;
            try
            {
                if (bill.BillId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Bill Id is required cannnot be blank");
                    validBill = false;
                }
                if (bill.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validBill = false;
                }
                else if (bill.PatientId == "Select")
                {
                    sb.Append(Environment.NewLine + "Patient Id is required");
                    validBill = false;
                }
                if (bill.DoctorId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                    validBill = false;
                }
                else if (bill.DoctorId == "Select")
                {
                    sb.Append(Environment.NewLine + "Doctor Id is Required");
                    validBill = false;
                }
                if (validBill == false)
                    throw new Hospital_Exceptions(sb.ToString());
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validBill;
        }

        private static bool ValidateLab(LabReport lab)
        {
            StringBuilder sb = new StringBuilder();
            bool validLab = true;
            try
            {
                if (lab.LabId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Lab Id is required cannnot be blank");
                    validLab = false;
                }
                if (lab.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validLab = false;
                }
                else if (lab.PatientId == "Select")
                {
                    sb.Append(Environment.NewLine + "Patient Id is Required");
                    validLab = false;
                }
                if (lab.DoctorId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                    validLab = false;
                }
                if (validLab == false)
                    throw new Hospital_Exceptions(sb.ToString());
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validLab;
        }

        private static bool ValidateInPatient(InPatient inPatient)
        {
            StringBuilder sb = new StringBuilder();
            bool validInPatient = true;
            try
            {
                if (inPatient.LabId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Lab Id is required cannnot be blank");
                    validInPatient = false;
                }
                else if (inPatient.LabId == "Select")
                {
                    sb.Append(Environment.NewLine + "Lab Id is Required");
                    validInPatient = false;
                }
                if (inPatient.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validInPatient = false;
                }
                if (inPatient.RoomNo == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Room Id is required cannnot be blank");
                    validInPatient = false;
                }

                else if (inPatient.RoomNo == "Select")
                {
                    sb.Append(Environment.NewLine + "Room Id is Required");
                    validInPatient = false;
                }
                if (inPatient.DoctorId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                    validInPatient = false;
                }
                else if (inPatient.DoctorId == "Select")
                {
                    sb.Append(Environment.NewLine + "Doctor Id is Required");
                    validInPatient = false;
                }
                if (inPatient.AdmissionDate == null)
                {
                    sb.Append(Environment.NewLine + "Admission Date is Required");
                    validInPatient = false;
                }
                if (inPatient.DischargeDate == null)
                {
                    sb.Append(Environment.NewLine + "Discharge Date is Required");
                    validInPatient = false;
                }
                if (inPatient.Amount <= 0)
                {
                    sb.Append(Environment.NewLine + "Enter the Amount Per Day");
                    validInPatient = false;
                }
                if (validInPatient == false)
                    throw new Hospital_Exceptions(sb.ToString());
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validInPatient;
        }

        //public static DataSet SearchInPatientByDoctorBAL(string docid)
        //{
        //    throw new NotImplementedException();
        //}

        private static bool ValidateOutPatient(OutPatient outPatient)
        {
            StringBuilder sb = new StringBuilder();
            bool validOutPatient = true;
            try
            {
                if (outPatient.LabId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Lab Id is required cannnot be blank");
                    validOutPatient = false;
                }
                else if (outPatient.LabId == "Select")
                {
                    sb.Append(Environment.NewLine + "Lab Id is Required");
                    validOutPatient = false;
                }
                if (outPatient.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validOutPatient = false;
                }
                if (outPatient.DoctorId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                    validOutPatient = false;
                }
                else if (outPatient.DoctorId == "Select")
                {
                    sb.Append(Environment.NewLine + "Doctor Id is Required");
                    validOutPatient = false;
                }
                if (outPatient.TreatmentDate == null)
                {
                    sb.Append(Environment.NewLine + "Treatment Date is Required");
                    validOutPatient = false;
                }
                if (validOutPatient == false)
                    throw new Hospital_Exceptions(sb.ToString());
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validOutPatient;
        }

        public static bool AddPatientBAL(Patient patient)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(patient))
                {
                    Hospital_Dal patientDAL = new Hospital_Dal();
                    patientAdded = patientDAL.AddPatientDAL(patient);
                    return patientAdded;
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        public static bool UpdatePatientBAL(Patient patient)
        {
            bool patientUpdated = false;
            try
            {
                if (ValidatePatient(patient))
                {
                    Hospital_Dal patientDAL = new Hospital_Dal();
                    patientUpdated = patientDAL.UpdatePatientDAL(patient);
                    return patientUpdated;
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientUpdated;
        }

        public static bool DeletePatientBAL(string PatientId)
        {

            bool PatientDeleted = false;
            try
            {
                if (PatientId != null)
                {
                    Hospital_Dal patientDAL = new Hospital_Dal();

                    PatientDeleted = patientDAL.DeletePatientDAL(PatientId);
                }
                else
                {
                    throw new Hospital_Exceptions("Invalid OutPatient ID");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return PatientDeleted;
        }

        public static Patient SearchPatientbyPatientIDBAL(string patientId)
        {
            Patient patient = null;
            try
            {
                if (patientId != null)
                {
                    Hospital_Dal patientDAL = new Hospital_Dal();
                    patient = patientDAL.SearchPatientbyPatientIdDAL(patientId);
                }
                else
                {
                    throw new Hospital_Exceptions("Patient Id is Required.");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patient;
        }

        public static List<Patient> GetAllPatientBAL()
        {
            List<Patient> patientList;
            try
            {
                Hospital_Dal patient = new Hospital_Dal();
                patientList = patient.GetAllPatientsDAL();
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientList;
        }








        //List details

        public static DataTable GetDoctorBAL()
        {
            DataTable doctorListIds;
            try
            {
                Hospital_Dal patientDAL = new Hospital_Dal();
                doctorListIds = patientDAL.GetDoctorIds();
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return doctorListIds;
        }
        public static DataTable GetLabBAL()
        {
            DataTable labList;
            try
            {
                Hospital_Dal labDAL = new Hospital_Dal();
                labList = labDAL.GetLabIds();
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return labList;
        }
        public static DataTable GetRoomBAL()
        {
            DataTable roomList;
            try
            {
                Hospital_Dal roomDAL = new Hospital_Dal();
                roomList = roomDAL.GetRoomDAL();
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return roomList;
        }

        public static DataTable GetPatientBAL()
        {
            DataTable patientList;
            try
            {
                Hospital_Dal patientDAL = new Hospital_Dal();
                patientList = patientDAL.GetPatientDAL();
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientList;
        }



        //InPatient Information

        public static bool AddInPatientBAL(InPatient newInPatient)
        {
            bool InpatientAdded = false;
            try
            {
                if (ValidateInPatient(newInPatient))
                {
                    Hospital_Dal inpatientDAL=new Hospital_Dal();
                    InpatientAdded = inpatientDAL.AddInPatientDAL(newInPatient);

                    return InpatientAdded;
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return InpatientAdded;
        
    }

        public static bool UpdateInPatientBAL(InPatient UpdateInPatient)
        {
            bool InpatientUpdated = false;
            try
            {
                if (ValidateInPatient(UpdateInPatient))
                {
                    Hospital_Dal inPatientUpdateDAL = new Hospital_Dal();
                    InpatientUpdated = inPatientUpdateDAL.UpdateInPatientDAL(UpdateInPatient);
                    return InpatientUpdated;
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return InpatientUpdated;
        }


        public static InPatient SearchInPatientBAL(string searchInPatientID)
        {
            InPatient searchInPatient = null;
            try
            {
                if (searchInPatientID!= null)
                {
                    Hospital_Dal searchInPatientDAL = new Hospital_Dal();
                    searchInPatient = searchInPatientDAL.SearchInPatientDAL(searchInPatientID);
                }
                else
                {
                    throw new Hospital_Exceptions("Patient Id must be greater than 0.");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchInPatient;
        }

        public static bool DeleteInPatientBAL(string deleteInPatientId)
        {
            bool InpatientDeleted = false;
            try
            {
                if (deleteInPatientId !=null)
                {
                    Hospital_Dal InpatientDal = new Hospital_Dal();
                    InpatientDeleted = InpatientDal.DeleteInPatientDAL(deleteInPatientId);
                }
                else
                {
                    throw new Hospital_Exceptions("Patient Id must be greater than 0.");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return InpatientDeleted;
        }

        public static List<InPatient> GetAllInPatientBAL()
        {
            List<InPatient> patientList;
            try
            {
                Hospital_Dal Inpatient = new Hospital_Dal();
                patientList = Inpatient.GetAllInPatients();
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientList;
        }


        //OutPatient Information
        public static bool AddOutPatientBAL(OutPatient newOutPatient)
        {
            bool OutpatientAdded = false;
            try
            {
                if (ValidateOutPatient(newOutPatient))
                {
                    Hospital_Dal inpatientDAL = new Hospital_Dal();
                    OutpatientAdded = inpatientDAL.AddOutPatientDAL(newOutPatient);

                    return OutpatientAdded;
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return OutpatientAdded;
        }

        public static bool UpdateOutPatientBAL(OutPatient UpdateOutPatient)
        {
            bool OutpatientUpdated = false;
            try
            {
                if (ValidateOutPatient(UpdateOutPatient))
                {
                    Hospital_Dal OutPatientUpdateDAL = new Hospital_Dal();
                    OutpatientUpdated = OutPatientUpdateDAL.UpdateOutPatientDAL(UpdateOutPatient);
                    return OutpatientUpdated;
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return OutpatientUpdated;
        }

        public static bool DeleteOutPatientBAL(string deleteOutPatientId)
        {
            bool OutpatientDeleted = false;
            try
            {
                if (deleteOutPatientId != null)
                {
                    Hospital_Dal InpatientDal = new Hospital_Dal();
                    OutpatientDeleted = InpatientDal.DeleteOutPatientDAL(deleteOutPatientId);
                }
                else
                {
                    throw new Hospital_Exceptions("Patient Id must be greater than 0.");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return OutpatientDeleted;
        }
        public static OutPatient SearchOutPatientBAL(string searchOutPatientId)
        {
            OutPatient searchOutPatient = null;
            try
            {
                if (searchOutPatientId != null)
                {
                    Hospital_Dal searchOutPatientdal = new Hospital_Dal();
                    searchOutPatient = searchOutPatientdal.SearchOutPatientDAL(searchOutPatientId);
                }
                else
                {
                    throw new Hospital_Exceptions("Patient Id must be greater than 0.");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchOutPatient;
        }

        public static List<OutPatient> GetAllOutPatientBAL()
        {
            List<OutPatient> patientList;
            try
            {
                Hospital_Dal Outpatient = new Hospital_Dal();
                patientList = Outpatient.GetAllOutPatients();
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientList;
        }


        //Bill Generation
        public static bool AddBillBAL(BillGeneration newBill)
        {
            bool BillAdded = false;
            try
            {
                if (ValidateBill(newBill))
                {
                    Hospital_Dal inpatientDAL = new Hospital_Dal();
                    BillAdded = inpatientDAL.AddBillDAL(newBill);

                    return BillAdded;
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return BillAdded;
        }

        public static bool UpdateBillBAL(BillGeneration UpdateBill)
        {
            bool BillUpdated = false;
            try
            {
                if (ValidateBill(UpdateBill))
                {
                    Hospital_Dal inPatientUpdateDAL = new Hospital_Dal();
                    BillUpdated = inPatientUpdateDAL.UpdateBillDAL(UpdateBill);
                    return BillUpdated;
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return BillUpdated;
        }

        public static bool DeleteBillBAL(string PatientId)
        {

            bool BillDeleted = false;
            try
            {
                if (PatientId != null)
                {
                    Hospital_Dal billDAL = new Hospital_Dal();

                    BillDeleted = billDAL.DeleteBillDAL(PatientId);
                }
                else
                {
                    throw new Hospital_Exceptions("Invalid OutPatient ID");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return BillDeleted;
        }
        public static BillGeneration SearchBillBAL(string billId)
        {
            BillGeneration bill = null;

            try
            {
                if (billId != null)
                {
                    Hospital_Dal BillDAL = new Hospital_Dal();
                    bill = BillDAL.SearchBillDAL(billId);
                }
                else
                {
                    throw new Hospital_Exceptions("Bill Id is Required.");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return bill;
        }
        public static List<BillGeneration> GetAllBillSBAL()
        {
            List<BillGeneration> billList;
            try
            {
                Hospital_Dal bill = new Hospital_Dal();
                billList = bill.GetAllBillS();
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return billList;
        }

        //Lab Information
        public static bool AddLabBAL(LabReport lab)
        {
            bool LabAdded = false;
            try
            {
                if (ValidateLab(lab))
                {
                    Hospital_Dal LabDAL = new Hospital_Dal();
                    LabAdded = LabDAL.AddLabDAL(lab);
                    return LabAdded;
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return LabAdded;
        }

        public static bool UpdateLabBAL(LabReport lab)
        {
            bool LabUpdated = false;
            try
            {
                if (ValidateLab(lab))
                {
                    Hospital_Dal LabDAL = new Hospital_Dal();
                    LabUpdated = LabDAL.UpdateLabDAL(lab);
                    return LabUpdated;
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return LabUpdated;
        }

        public static bool DeleteLabBAL(string PatientId)
        {

            bool LabDeleted = false;
            try
            {
                if (PatientId != null)
                {
                    Hospital_Dal LabDAL = new Hospital_Dal();

                    LabDeleted = LabDAL.DeleteLabDAL(PatientId);
                }
                else
                {
                    throw new HMSException.Hospital_Exceptions("Invalid Lab no");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return LabDeleted;
        }

        public static LabReport SearchLabBAL(string patientId)
        {
            LabReport lab = null;

            try
            {
                if (patientId != null)
                {
                    Hospital_Dal LabDAL = new Hospital_Dal();
                    lab = LabDAL.SearchLabDAL(patientId);
                }
                else
                {
                    throw new Hospital_Exceptions("Patient is Required.");
                }
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lab;
        }

        public static List<LabReport> GetAllLabsBAL()
        {
            List<LabReport> labList;
            try
            {
                Hospital_Dal lab = new Hospital_Dal();
                labList = lab.GetAllLabsDAL();
            }
            catch (Hospital_Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return labList;
        }
    }
}





