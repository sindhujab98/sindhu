﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using HMSEntities;
using HMSException;
using System.Configuration;


namespace HMSDAL
{
    public class Hospital_Dal
    {
        public bool AddPatientDAL(Patient objPatient)
        {
            bool patientAdded = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].InsertPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", objPatient.PatientId);
                SqlParameter objSqlParam_DoctorId = new SqlParameter("@DoctorId", objPatient.DoctorId);
                SqlParameter objSqlParam_PatientName = new SqlParameter("@PatientName", objPatient.PatientName);
                SqlParameter objSqlParam_PhoneNo = new SqlParameter("@PhoneNo", objPatient.PhoneNo);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", objPatient.Gender);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", objPatient.Age);
                SqlParameter objSqlParam_PWeight = new SqlParameter("@PWeight", objPatient.PWeight);
                SqlParameter objSqlParam_PAddress = new SqlParameter("@PAddress", objPatient.PAddress);
                SqlParameter objSqlParam_Disease = new SqlParameter("@Disease", objPatient.Disease);
                //
                Com.Parameters.Add(objSqlParam_PatientId);
                Com.Parameters.Add(objSqlParam_DoctorId);
                Com.Parameters.Add(objSqlParam_PatientName);
                Com.Parameters.Add(objSqlParam_PhoneNo);
                Com.Parameters.Add(objSqlParam_Gender);
                Com.Parameters.Add(objSqlParam_Age);
                Com.Parameters.Add(objSqlParam_PWeight);
                Com.Parameters.Add(objSqlParam_PAddress);
                Com.Parameters.Add(objSqlParam_Disease);

                //
                Con.Open();
                Com.ExecuteNonQuery();
                patientAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return patientAdded;
        }
        public bool UpdatePatientDAL(Patient objPatient)
        {
            bool patientUpdated = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].UpdatePatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", objPatient.PatientId);
                SqlParameter objSqlParam_DoctorId = new SqlParameter("@DoctorId", objPatient.DoctorId);
                SqlParameter objSqlParam_PatientName = new SqlParameter("@PatientName", objPatient.PatientName);
                SqlParameter objSqlParam_PhoneNo = new SqlParameter("@PhoneNo", objPatient.PhoneNo);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", objPatient.Gender);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", objPatient.Age);
                SqlParameter objSqlParam_PWeight = new SqlParameter("@PWeight", objPatient.PWeight);
                SqlParameter objSqlParam_PAddress = new SqlParameter("@PAddress", objPatient.PAddress);
                SqlParameter objSqlParam_Disease = new SqlParameter("@Disease", objPatient.Gender);
                //
                Com.Parameters.Add(objSqlParam_PatientId);
                Com.Parameters.Add(objSqlParam_DoctorId);
                Com.Parameters.Add(objSqlParam_PatientName);
                Com.Parameters.Add(objSqlParam_PhoneNo);
                Com.Parameters.Add(objSqlParam_Gender);
                Com.Parameters.Add(objSqlParam_Age);
                Com.Parameters.Add(objSqlParam_PWeight);
                Com.Parameters.Add(objSqlParam_PAddress);
                Com.Parameters.Add(objSqlParam_Disease);

                //
                Con.Open();
                Com.ExecuteNonQuery();
                patientUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return patientUpdated;
        }

        public bool DeletePatientDAL(string PatientId)
        {
            bool patientDeleted = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].DeletePatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", PatientId);

                //
                Com.Parameters.Add(objSqlParam_PatientId);

                Con.Open();
                Com.ExecuteNonQuery();
                patientDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return patientDeleted;
        }

        public Patient SearchPatientbyPatientIdDAL(string PatientId)
        {
            Patient objPatient = null;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].SelectPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_DoctorId = new SqlParameter("@DoctorId", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_PatientName = new SqlParameter("@PatientName", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_PhoneNo = new SqlParameter("@PhoneNo", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", SqlDbType.VarChar, 10);
                SqlParameter objSqlParam_Age = new SqlParameter("@Age", SqlDbType.Int);
                SqlParameter objSqlParam_PWeight = new SqlParameter("@PWeight", SqlDbType.Float);
                SqlParameter objSqlParam_PAddress = new SqlParameter("@PAddress", SqlDbType.VarChar, 100);
                SqlParameter objSqlParam_Disease = new SqlParameter("@Disease", SqlDbType.VarChar, 100);
                //
                objSqlParam_PatientId.Direction = ParameterDirection.Input;
                objSqlParam_DoctorId.Direction = ParameterDirection.Output;
                objSqlParam_PatientName.Direction = ParameterDirection.Output;
                objSqlParam_PhoneNo.Direction = ParameterDirection.Output;
                objSqlParam_Gender.Direction = ParameterDirection.Output;
                objSqlParam_Age.Direction = ParameterDirection.Output;
                objSqlParam_PWeight.Direction = ParameterDirection.Output;
                objSqlParam_PAddress.Direction = ParameterDirection.Output;
                objSqlParam_Disease.Direction = ParameterDirection.Output;



                //
                Com.Parameters.Add(objSqlParam_PatientId);
                Com.Parameters.Add(objSqlParam_DoctorId);
                Com.Parameters.Add(objSqlParam_PatientName);
                Com.Parameters.Add(objSqlParam_PhoneNo);
                Com.Parameters.Add(objSqlParam_Gender);
                Com.Parameters.Add(objSqlParam_Age);
                Com.Parameters.Add(objSqlParam_PWeight);
                Com.Parameters.Add(objSqlParam_PAddress);
                Com.Parameters.Add(objSqlParam_Disease);

                //
                objSqlParam_PatientId.Value = PatientId;
                //
                Con.Open();
                Com.ExecuteNonQuery();
                objPatient = new Patient();
                objPatient.PatientId = objSqlParam_PatientId.Value as string;
                objPatient.DoctorId = objSqlParam_DoctorId.Value as string;
                objPatient.PatientName = objSqlParam_PatientName.Value as string;
                objPatient.PhoneNo = objSqlParam_PhoneNo.Value as string;
                objPatient.Gender = objSqlParam_Gender.Value as string;
                objPatient.Age = Convert.ToInt16(objSqlParam_Age.Value);
                objPatient.PWeight = Convert.ToDouble(objSqlParam_PWeight.Value);
                objPatient.PAddress = objSqlParam_PAddress.Value as string;
                objPatient.Disease = objSqlParam_Disease.Value as string;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return objPatient;
        }

        
        public List<Patient> GetAllPatientsDAL()
        {
            List<Patient> Patients = new List<Patient>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009517].ListPatient", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Patient objPatient = new Patient();
                    objPatient.PatientId = objDR[0] as string;
                    objPatient.PatientName = objDR[1] as string;
                    objPatient.Age = Convert.ToInt32(objDR[2]);
                    objPatient.PWeight = Convert.ToDouble(objDR[3]);
                    objPatient.Gender = objDR[4] as string;
                    objPatient.PAddress = objDR[5] as string;
                    objPatient.PhoneNo = objDR[6] as string;
                    objPatient.Disease = objDR[7] as string;
                    objPatient.DoctorId = objDR[8] as string;
                    
                    Patients.Add(objPatient);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return Patients;
        }












        //List Details

        public DataTable GetDoctorIds ()
        {
            DataTable doctorListIds = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009517].GetDoctor", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                doctorListIds = new DataTable();
                doctorListIds.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new Hospital_Exceptions(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return doctorListIds;
        }
        public DataTable GetLabIds()
        {
            DataTable labListIds = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009517].GetLab", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                labListIds = new DataTable();
                labListIds.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new Hospital_Exceptions(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return labListIds;
        }

        public DataTable GetRoomDAL()
        {
            DataTable roomListIds = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009517].GetRoom", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                roomListIds = new DataTable();
                roomListIds.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new Hospital_Exceptions(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return roomListIds;
        }

        public DataTable GetPatientDAL()
        {
            DataTable patientList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009517].ListPatient", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                patientList = new DataTable();
                patientList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new Hospital_Exceptions(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return patientList;
        }




        //InPatient Information

        public bool AddInPatientDAL(InPatient objInPatient)
        {

            bool InpatientAdded = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].Insert_InPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", objInPatient.PatientId);
                SqlParameter objSqlParam_RoomNo = new SqlParameter("@RoomNo", objInPatient.RoomNo);
                SqlParameter objSqlParam_DoctorId = new SqlParameter("@DoctorId", objInPatient.DoctorId);
                SqlParameter objSqlParam_AdmissionDate = new SqlParameter("@AdmissionDate", objInPatient.AdmissionDate);
                SqlParameter objSqlParam_DischargeDate = new SqlParameter("@DischargeDate", objInPatient.DischargeDate);
                SqlParameter objSqlParam_LabId = new SqlParameter("@LabId", objInPatient.LabId);                   
                SqlParameter objSqlParam_Amount = new SqlParameter("@Amount", objInPatient.Amount);
                
                //
                Com.Parameters.Add(objSqlParam_PatientId);
                Com.Parameters.Add(objSqlParam_RoomNo);
                Com.Parameters.Add(objSqlParam_DoctorId);
                Com.Parameters.Add(objSqlParam_AdmissionDate);
                Com.Parameters.Add(objSqlParam_DischargeDate);
                Com.Parameters.Add(objSqlParam_LabId);                              
                Com.Parameters.Add(objSqlParam_Amount);
                             
                //
                Con.Open();
                Com.ExecuteNonQuery();
                InpatientAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return InpatientAdded;
        }

        public bool UpdateInPatientDAL(InPatient updateInPatient)
        {
            bool InpatientUpdated = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].Update_InPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", updateInPatient.PatientId);
                SqlParameter objSqlParam_RoomNo = new SqlParameter("@RoomNo", updateInPatient.RoomNo);
                SqlParameter objSqlParam_DoctorId = new SqlParameter("@DoctorId", updateInPatient.DoctorId);
                SqlParameter objSqlParam_AdmissionDate = new SqlParameter("@AdmissionDate", updateInPatient.AdmissionDate);
                SqlParameter objSqlParam_DischargeDate = new SqlParameter("@DischargeDate", updateInPatient.DischargeDate);
                SqlParameter objSqlParam_LabId = new SqlParameter("@LabId", updateInPatient.LabId);
                SqlParameter objSqlParam_Amount = new SqlParameter("@Amount", updateInPatient.Amount);

                //
                Com.Parameters.Add(objSqlParam_PatientId);
                Com.Parameters.Add(objSqlParam_DoctorId);
                Com.Parameters.Add(objSqlParam_LabId);
                Com.Parameters.Add(objSqlParam_RoomNo);
                Com.Parameters.Add(objSqlParam_DischargeDate);
                Com.Parameters.Add(objSqlParam_Amount);
                Com.Parameters.Add(objSqlParam_AdmissionDate);

                //
                Con.Open();
                Com.ExecuteNonQuery();
                InpatientUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return InpatientUpdated;
        }

        public InPatient SearchInPatientDAL(string searchInPatientID)
        {

            InPatient searchPatient = null;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].[Select_InPatient]", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", SqlDbType.VarChar,10);
                SqlParameter objSqlParam_RoomNo = new SqlParameter("@RoomNo", SqlDbType.VarChar, 10);
                SqlParameter objSqlParam_DoctorId = new SqlParameter("@DoctorId", SqlDbType.VarChar, 10);
                SqlParameter objSqlParam_AdmissionDate = new SqlParameter("@AdmissionDate", SqlDbType.Date);
                SqlParameter objSqlParam_DischargeDate = new SqlParameter("@DischargeDate", SqlDbType.Date);
                SqlParameter objSqlParam_LabId = new SqlParameter("@LabId", SqlDbType.VarChar, 10);
                SqlParameter objSqlParam_Amount = new SqlParameter("@Amount", SqlDbType.Real);

                //
                objSqlParam_PatientId.Direction = ParameterDirection.Input;
                objSqlParam_RoomNo.Direction = ParameterDirection.Output;
                objSqlParam_DoctorId.Direction = ParameterDirection.Output;
                objSqlParam_AdmissionDate.Direction = ParameterDirection.Output;
                objSqlParam_DischargeDate.Direction = ParameterDirection.Output;
                objSqlParam_LabId.Direction = ParameterDirection.Output;
                objSqlParam_Amount.Direction = ParameterDirection.Output;

                //
                Com.Parameters.Add(objSqlParam_PatientId);
                Com.Parameters.Add(objSqlParam_DoctorId);
                Com.Parameters.Add(objSqlParam_RoomNo);
                Com.Parameters.Add(objSqlParam_AdmissionDate);
                Com.Parameters.Add(objSqlParam_DischargeDate);
                Com.Parameters.Add(objSqlParam_LabId);
                Com.Parameters.Add(objSqlParam_Amount);
                //
                objSqlParam_PatientId.Value = searchInPatientID;
                Con.Open();
                Com.ExecuteNonQuery();
                searchPatient = new InPatient();
                searchPatient.PatientId = objSqlParam_PatientId.Value as string;
                searchPatient.RoomNo = objSqlParam_RoomNo.Value as string;
                searchPatient.DoctorId = objSqlParam_DoctorId.Value as string;
                searchPatient.AdmissionDate = Convert.ToDateTime(objSqlParam_AdmissionDate.Value);
                searchPatient.DischargeDate = Convert.ToDateTime(objSqlParam_DischargeDate.Value);
                searchPatient.LabId = objSqlParam_LabId.Value as string;
                searchPatient.Amount = Convert.ToDouble(objSqlParam_Amount.Value);
                Con.Close();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Con.Close();
            }
            return searchPatient;
        }

        public bool DeleteInPatientDAL(string deleteInPatientId)
        {
            bool patientDeleted = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].[Delete_InPatient]", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", deleteInPatientId);

                //
                Com.Parameters.Add(objSqlParam_PatientId);

                Con.Open();
                Com.ExecuteNonQuery();
                patientDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return patientDeleted;
        }


        public List<InPatient> GetAllInPatients()
        {
            List<InPatient> InPatients = new List<InPatient>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009517].List_InPatient", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    InPatient objPatient = new InPatient();
                    objPatient.PatientId = objDR[0] as string;
                    objPatient.RoomNo = objDR[1] as string;
                    objPatient.DoctorId = objDR[2] as string;
                    objPatient.AdmissionDate = Convert.ToDateTime(objDR[3]);
                    objPatient.DischargeDate = Convert.ToDateTime(objDR[4]);
                    objPatient.LabId = objDR[5] as string;
                    objPatient.Amount = Convert.ToDouble(objDR[6]);

                    InPatients.Add(objPatient);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return InPatients;
        }



        //OutPatient Information
        public bool AddOutPatientDAL(OutPatient objOutPatient)
        {

            bool OutpatientAdded = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].Insert_OutPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;

                //
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", objOutPatient.PatientId);
                SqlParameter objSqlParam_TreatmentDate = new SqlParameter("@TreatmentDate", objOutPatient.TreatmentDate);
                SqlParameter objSqlParam_DoctorId = new SqlParameter("@DoctorId", objOutPatient.DoctorId);
                SqlParameter objSqlParam_LabId = new SqlParameter("@LabId", objOutPatient.LabId);

                //
                Com.Parameters.Add(objSqlParam_PatientId);
                Com.Parameters.Add(objSqlParam_TreatmentDate);
                Com.Parameters.Add(objSqlParam_DoctorId);
                Com.Parameters.Add(objSqlParam_LabId);
               
                //
                Con.Open();
                Com.ExecuteNonQuery();
                OutpatientAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return OutpatientAdded;
        }

        public bool UpdateOutPatientDAL(OutPatient updateOutPatient)
        {
            bool OutpatientUpdated = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].Update_OutPatient", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", updateOutPatient.PatientId);
                SqlParameter objSqlParam_TreatmentDate = new SqlParameter("@TreatmentDate", updateOutPatient.TreatmentDate);
                SqlParameter objSqlParam_DoctorId = new SqlParameter("@DoctorId", updateOutPatient.DoctorId);               
                SqlParameter objSqlParam_LabId = new SqlParameter("@LabId", updateOutPatient.LabId);


                //
                Com.Parameters.Add(objSqlParam_PatientId);
                Com.Parameters.Add(objSqlParam_TreatmentDate);
                Com.Parameters.Add(objSqlParam_DoctorId);
                Com.Parameters.Add(objSqlParam_LabId);
                
                //
                Con.Open();
                Com.ExecuteNonQuery();
                OutpatientUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return OutpatientUpdated;
        }
        public bool DeleteOutPatientDAL(string deleteOutPatientId)
        {
            bool patientDeleted = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].[Delete_InPatient]", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", deleteOutPatientId);

                //
                Com.Parameters.Add(objSqlParam_PatientId);

                Con.Open();
                Com.ExecuteNonQuery();
                patientDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return patientDeleted;
        }

        public OutPatient SearchOutPatientDAL(string searchOutPatientId)
        {

            OutPatient searchOutPatient = null;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].[Select_OutPatient]", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", SqlDbType.VarChar, 10);
                SqlParameter objSqlParam_TreatmentDate = new SqlParameter("@TreatmentDate", SqlDbType.Date);
                SqlParameter objSqlParam_DoctorId = new SqlParameter("@DoctorId", SqlDbType.VarChar, 10);
                SqlParameter objSqlParam_LabId = new SqlParameter("@LabId", SqlDbType.VarChar, 10);

                //
                objSqlParam_PatientId.Direction = ParameterDirection.Input;
                objSqlParam_TreatmentDate.Direction = ParameterDirection.Output;
                objSqlParam_DoctorId.Direction = ParameterDirection.Output;                              
                objSqlParam_LabId.Direction = ParameterDirection.Output;
                
                //
                Com.Parameters.Add(objSqlParam_PatientId);
                Com.Parameters.Add(objSqlParam_TreatmentDate);
                Com.Parameters.Add(objSqlParam_DoctorId);               ;
                Com.Parameters.Add(objSqlParam_LabId);
               
                //
                objSqlParam_PatientId.Value = searchOutPatientId;
                Con.Open();
                Com.ExecuteNonQuery();
                searchOutPatient = new OutPatient();
                searchOutPatient.PatientId = objSqlParam_PatientId.Value as string;
                searchOutPatient.TreatmentDate = Convert.ToDateTime(objSqlParam_TreatmentDate.Value);
                searchOutPatient.DoctorId = objSqlParam_DoctorId.Value as string;
                searchOutPatient.LabId = objSqlParam_LabId.Value as string;
              ;
                Con.Close();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Con.Close();
            }
            return searchOutPatient;
        }

        public List<OutPatient> GetAllOutPatients()
        {
            List<OutPatient> OutPatients = new List<OutPatient>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009517].List_OutPatient", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    OutPatient objPatient = new OutPatient();
                    objPatient.PatientId = objDR[0] as string;
                    objPatient.TreatmentDate = Convert.ToDateTime(objDR[1]);                   
                    objPatient.DoctorId = objDR[2] as string;                                  
                    objPatient.LabId = objDR[3] as string;
                   
                    OutPatients.Add(objPatient);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return OutPatients;
        }


        //Bill Generation
        public bool AddBillDAL(BillGeneration objBill)
        {
            bool BillAdded = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].Insert_Bill", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_BillId = new SqlParameter("@BillId", objBill.BillId);
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", objBill.PatientId);
                SqlParameter objSqlParam_PatientType = new SqlParameter("@PatientType", objBill.PatientType);
                SqlParameter objSqlParam_DoctorId = new SqlParameter("@DoctorId", objBill.DoctorId);
                SqlParameter objSqlParam_DoctorFee = new SqlParameter("@DoctorFee", objBill.DoctorFees);
                SqlParameter objSqlParam_RoomCharge = new SqlParameter("@RoomCharge", objBill.RoomCharges);
                SqlParameter objSqlParam_OperationCharges = new SqlParameter("@OperationCharges", objBill.OperationCharges);
                SqlParameter objSqlParam_MedicineFees = new SqlParameter("@MedicineFee", objBill.MedicineFees);
                SqlParameter objSqlParam_TotalDays = new SqlParameter("@TotalDays", objBill.TotalDays);
                SqlParameter objSqlParam_LabFees = new SqlParameter("@LabFee", objBill.LabFees);
                SqlParameter objSqlParam_TotalAmount = new SqlParameter("@TotalAmount", objBill.TotalAmount);


                //
                Com.Parameters.Add(objSqlParam_BillId);
                Com.Parameters.Add(objSqlParam_PatientId);
                Com.Parameters.Add(objSqlParam_PatientType);
                Com.Parameters.Add(objSqlParam_DoctorId);
                Com.Parameters.Add(objSqlParam_DoctorFee);
                Com.Parameters.Add(objSqlParam_RoomCharge);
                Com.Parameters.Add(objSqlParam_OperationCharges);
                Com.Parameters.Add(objSqlParam_MedicineFees);
                Com.Parameters.Add(objSqlParam_TotalDays);
                Com.Parameters.Add(objSqlParam_LabFees);
                Com.Parameters.Add(objSqlParam_TotalAmount);
               
                //
                Con.Open();
                Com.ExecuteNonQuery();
                BillAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return BillAdded;
        }
        public bool UpdateBillDAL(BillGeneration objBill)
        {
            bool BillUpdated = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].Update_Bill", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_BillId = new SqlParameter("@BillId", objBill.BillId);
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", objBill.PatientId);
                SqlParameter objSqlParam_PatientType = new SqlParameter("@PatientType", objBill.PatientType);
                SqlParameter objSqlParam_DoctorId = new SqlParameter("@DoctorId", objBill.DoctorId);
                SqlParameter objSqlParam_DoctorFee = new SqlParameter("@DoctorFee", objBill.DoctorFees);
                SqlParameter objSqlParam_RoomCharge = new SqlParameter("@RoomCharge", objBill.RoomCharges);
                SqlParameter objSqlParam_OperationCharges = new SqlParameter("@OperationCharges", objBill.OperationCharges);
                SqlParameter objSqlParam_MedicineFees = new SqlParameter("@MedicineFee", objBill.MedicineFees);
                SqlParameter objSqlParam_TotalDays = new SqlParameter("@TotalDays", objBill.TotalDays);
                SqlParameter objSqlParam_LabFees = new SqlParameter("@LabFee", objBill.LabFees);
                SqlParameter objSqlParam_TotalAmount = new SqlParameter("@totalAmount", objBill.TotalAmount);
                //
                Com.Parameters.Add(objSqlParam_BillId);
                Com.Parameters.Add(objSqlParam_PatientId);
                Com.Parameters.Add(objSqlParam_PatientType);
                Com.Parameters.Add(objSqlParam_DoctorId);
                Com.Parameters.Add(objSqlParam_DoctorFee);
                Com.Parameters.Add(objSqlParam_RoomCharge);
                Com.Parameters.Add(objSqlParam_OperationCharges);
                Com.Parameters.Add(objSqlParam_MedicineFees);
                Com.Parameters.Add(objSqlParam_TotalDays);
                Com.Parameters.Add(objSqlParam_LabFees);
                Com.Parameters.Add(objSqlParam_TotalAmount);

                //
                Con.Open();
                Com.ExecuteNonQuery();
                BillUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return BillUpdated;
        }

        public bool DeleteBillDAL(string deletebillId)
        {
            bool billDeleted = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].[Delete_Bill]", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", deletebillId);

                //
                Com.Parameters.Add(objSqlParam_PatientId);

                Con.Open();
                Com.ExecuteNonQuery();
                billDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return billDeleted;
        }
        public BillGeneration SearchBillDAL(string BillId)
        {
            BillGeneration objBill = null;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].Select_Bill", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_BillId = new SqlParameter("@BillId", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_PatientType = new SqlParameter("@PatientType", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_DoctorId = new SqlParameter("@DoctorId", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_DoctorFees = new SqlParameter("@DoctorFee", SqlDbType.Real);
                SqlParameter objSqlParam_RoomCharges = new SqlParameter("@RoomCharge", SqlDbType.Real);
                SqlParameter objSqlParam_OperationCharges = new SqlParameter("@OperationCharges", SqlDbType.Real);
                SqlParameter objSqlParam_MedicineFees = new SqlParameter("@MedicineFee", SqlDbType.Real);
                SqlParameter objSqlParam_TotalDays = new SqlParameter("@TotalDays", SqlDbType.Int);
                SqlParameter objSqlParam_LabFees = new SqlParameter("@LabFee", SqlDbType.Real);
                SqlParameter objSqlParam_TotalAmount = new SqlParameter("@TotalAmount", SqlDbType.Real);
                //
                objSqlParam_BillId.Direction = ParameterDirection.Input;
                objSqlParam_PatientId.Direction = ParameterDirection.Output;
                objSqlParam_PatientType.Direction = ParameterDirection.Output;
                objSqlParam_DoctorId.Direction = ParameterDirection.Output;
                objSqlParam_DoctorFees.Direction = ParameterDirection.Output;
                objSqlParam_RoomCharges.Direction = ParameterDirection.Output;
                objSqlParam_OperationCharges.Direction = ParameterDirection.Output;
                objSqlParam_MedicineFees.Direction = ParameterDirection.Output;
                objSqlParam_TotalDays.Direction = ParameterDirection.Output;
                objSqlParam_LabFees.Direction = ParameterDirection.Output;
                objSqlParam_TotalAmount.Direction = ParameterDirection.Output;



                //
                Com.Parameters.Add(objSqlParam_BillId);
                Com.Parameters.Add(objSqlParam_PatientId);
                Com.Parameters.Add(objSqlParam_PatientType);
                Com.Parameters.Add(objSqlParam_DoctorId);
                Com.Parameters.Add(objSqlParam_RoomCharges);
                Com.Parameters.Add(objSqlParam_DoctorFees);
                Com.Parameters.Add(objSqlParam_OperationCharges);
                Com.Parameters.Add(objSqlParam_MedicineFees);
                Com.Parameters.Add(objSqlParam_TotalDays);
                Com.Parameters.Add(objSqlParam_LabFees);
                Com.Parameters.Add(objSqlParam_TotalAmount);

                //
                objSqlParam_BillId.Value = BillId;
                //
                Con.Open();
                Com.ExecuteNonQuery();
                objBill = new BillGeneration();
                objBill.BillId = objSqlParam_BillId.Value as string;
                objBill.PatientId = objSqlParam_PatientId.Value as string;
                objBill.PatientType = objSqlParam_PatientType.Value as string;
                objBill.DoctorId = objSqlParam_DoctorId.Value as string;
                objBill.DoctorFees = Convert.ToDouble(objSqlParam_DoctorFees.Value);
                objBill.RoomCharges = Convert.ToDouble(objSqlParam_RoomCharges.Value);
                objBill.OperationCharges = Convert.ToDouble(objSqlParam_OperationCharges.Value);
                objBill.MedicineFees = Convert.ToDouble(objSqlParam_MedicineFees.Value);
                objBill.LabFees = Convert.ToDouble(objSqlParam_LabFees.Value);
                objBill.TotalDays = Convert.ToInt32(objSqlParam_TotalDays.Value);
                objBill.TotalAmount = Convert.ToDouble(objSqlParam_TotalAmount.Value);

            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return objBill;
        }
        public List<BillGeneration> GetAllBillS()
        {
            List<BillGeneration> bill = new List<BillGeneration>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009517].List_Bill", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    BillGeneration objBill = new BillGeneration();
                    objBill.BillId = objDR[0] as string;
                    objBill.PatientId = objDR[1] as string;
                    objBill.PatientType = objDR[2] as string;
                    objBill.DoctorId = objDR[3] as string;
                    objBill.DoctorFees = Convert.ToDouble(objDR[4]);
                    objBill.RoomCharges = Convert.ToDouble(objDR[5]);
                    objBill.OperationCharges = Convert.ToDouble(objDR[6]);
                    objBill.MedicineFees = Convert.ToDouble(objDR[7]);
                    objBill.TotalDays = Convert.ToInt32(objDR[8]);
                    objBill.LabFees = Convert.ToDouble(objDR[9]);
                    objBill.TotalAmount = Convert.ToDouble(objDR[10]);
                    bill.Add(objBill);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return bill;
        }


        //Lab Information
        public bool AddLabDAL(LabReport objlab)
        {
            bool LabAdded = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].Insert_Lab", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_LabId = new SqlParameter("@LabId", objlab.LabId);
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", objlab.PatientId);
                SqlParameter objSqlParam_DoctorId = new SqlParameter("@DoctorId", objlab.DoctorId);
                SqlParameter objSqlParam_TestDate = new SqlParameter("@TestDate", objlab.TestDate);
                SqlParameter objSqlParam_TestType = new SqlParameter("@TestType", objlab.TestType);
                SqlParameter objSqlParam_PatientType = new SqlParameter("@PatientType", objlab.PatientType);
                //       
                Com.Parameters.Add(objSqlParam_LabId);
                Com.Parameters.Add(objSqlParam_PatientId);
                Com.Parameters.Add(objSqlParam_DoctorId);
                Com.Parameters.Add(objSqlParam_TestDate);
                Com.Parameters.Add(objSqlParam_TestType);
                Com.Parameters.Add(objSqlParam_PatientType);
                //
                Con.Open();
                Com.ExecuteNonQuery();
                LabAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return LabAdded;
        }


        public bool UpdateLabDAL(LabReport objLab)
        {
            bool LabUpdated = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].Update_Lab", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_LabId = new SqlParameter("@LabId", objLab.LabId);
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", objLab.PatientId);
                SqlParameter objSqlParam_DoctorId = new SqlParameter("@DoctorId", objLab.DoctorId);
                SqlParameter objSqlParam_TestDate = new SqlParameter("@TestDate", objLab.TestDate);
                SqlParameter objSqlParam_TestType = new SqlParameter("@TestType", objLab.TestType);
                SqlParameter objSqlParam_PatientType = new SqlParameter("@PatientType", objLab.PatientType);
                //
                Com.Parameters.Add(objSqlParam_LabId);
                Com.Parameters.Add(objSqlParam_PatientId);
                Com.Parameters.Add(objSqlParam_DoctorId);
                Com.Parameters.Add(objSqlParam_TestDate);
                Com.Parameters.Add(objSqlParam_TestType);
                Com.Parameters.Add(objSqlParam_PatientType);
                //
                Con.Open();
                Com.ExecuteNonQuery();
                LabUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return LabUpdated;
        }
        public bool DeleteLabDAL(string PatientId)
        {
            bool LabDeleted = false;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].Delete_Lab", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", PatientId);

                //
                Com.Parameters.Add(objSqlParam_PatientId);

                Con.Open();
                Com.ExecuteNonQuery();
                LabDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return LabDeleted;
        }
        public LabReport SearchLabDAL(string patientId)
        {
            LabReport objLab = null;
            SqlConnection Con = null;
            try
            {
                Con = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand Com = new SqlCommand("[46009517].Select_Lab", Con);
                Com.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_LabId = new SqlParameter("@LabId", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_PatientId = new SqlParameter("@PatientId", SqlDbType.VarChar, 10);
                SqlParameter objSqlParam_DoctorId = new SqlParameter("@DoctorId", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_TestDate = new SqlParameter("@TestDate", SqlDbType.Date);
                SqlParameter objSqlParam_TestType = new SqlParameter("@TestType", SqlDbType.VarChar, 20);
                SqlParameter objSqlParam_PatientType = new SqlParameter("@PatientType", SqlDbType.VarChar, 20);

                //
                objSqlParam_LabId.Direction = ParameterDirection.Output;                    
                objSqlParam_PatientId.Direction = ParameterDirection.Input;
                objSqlParam_DoctorId.Direction = ParameterDirection.Output;
                objSqlParam_TestDate.Direction = ParameterDirection.Output;
                objSqlParam_TestType.Direction = ParameterDirection.Output;
                objSqlParam_PatientType.Direction = ParameterDirection.Output;

                //
                Com.Parameters.Add(objSqlParam_LabId);
                Com.Parameters.Add(objSqlParam_PatientId);
                Com.Parameters.Add(objSqlParam_DoctorId);
                Com.Parameters.Add(objSqlParam_TestDate);
                Com.Parameters.Add(objSqlParam_TestType);
                Com.Parameters.Add(objSqlParam_PatientType);

                //
                objSqlParam_PatientId.Value = patientId;
                //
                Con.Open();
                Com.ExecuteNonQuery();
                objLab = new LabReport();
                objLab.LabId = objSqlParam_LabId.Value as string;
                objLab.PatientId = patientId;
                objLab.DoctorId = objSqlParam_DoctorId.Value as string;
                objLab.TestDate = Convert.ToDateTime(objSqlParam_TestDate.Value);
                objLab.TestType = objSqlParam_TestType.Value as string;
                objLab.PatientType = objSqlParam_PatientType.Value as string;
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                Con.Close();
            }
            return objLab;
        }
        public List<LabReport> GetAllLabsDAL()
        {
            List<LabReport> Labs = new List<LabReport>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009517].GetLab", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    LabReport objLab = new LabReport();
                    objLab.LabId = objDR[0] as string;
                    objLab.PatientId = objDR[1] as string;
                    objLab.DoctorId = objDR[2] as string;
                    objLab.TestDate = Convert.ToDateTime(objDR[3]);
                    objLab.TestType = objDR[4] as string;
                    objLab.PatientType = objDR[5] as string;
                    Labs.Add(objLab);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new Hospital_Exceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return Labs;
        }
    }
}

























        