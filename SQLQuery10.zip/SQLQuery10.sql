USE [sindhu]
GO

/****** Object:  Table [46008916].[BillData]    Script Date: 11/15/2019 9:34:04 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO
create schema [46009517]

create TABLE [46009517].[BillData](
	[BillNo] [varchar](20) NOT NULL,
	[PatientId] [varchar](20) NULL,
	[PatientType] [varchar](20) NULL,
	[DoctorId] [varchar](20) NULL,
	[DoctorFee] [real] NULL,
	[RoomCharge] [real] NULL,
	[OperationCharges] [real] NULL,
	[MedicineFee] [real] NULL,
	[TotalDays] [int] NULL,
	[LabFee] [real] NULL,
	[TotalAmount] [real] NULL,
PRIMARY KEY CLUSTERED 
(
	[BillNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO




=================================================================================================
CREATE TABLE [46009517].[Doctor](
	[DoctorId] [varchar](20) NOT NULL,
	[DoctorName] [varchar](20) NULL,
	[Department] [varchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[DoctorID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

====================================================================================

create TABLE [46009517].[InPatient](
	[PatientId] [varchar](20) NOT NULL,
	[RoomNo] [varchar](20) NULL,
	[DoctorId] [varchar](20) NULL,
	[AdmissionDate] [date] NULL,
	[DischargeDate] [date] NULL,
	[LabId] [varchar](20) NULL,
	[Amount] [real] NULL,
PRIMARY KEY CLUSTERED 
(
	[PatientId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
=================================================================================

CREATE TABLE [46009517].[Lab](
	[LabId] [varchar](20) NOT NULL,
	[PatientId] [varchar](10) NULL,
	[DoctorId] [varchar](20) NULL,
	[TestDate] [date] NULL,
	[TestType] [varchar](50) NULL,
	[PatientType] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[LabId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

================================================================================================

CREATE TABLE [46009517].[OutPatient](
	[PatientId] [varchar](20) NOT NULL,
	[TreatmentDate] [date] NULL,
	[DoctorId] [varchar](20) NULL,
	[LabId] [varchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[PatientId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
========================================================================
create TABLE [46009517].[Patient](
	[PatientId] [varchar](10) NOT NULL,
	[PatientName] [varchar](20) NULL,
	[Age] [int] NULL,
	[PWeight] [real] NULL,
	[Gender] [varchar](10) NULL,
	[PAddress] [varchar](100) NULL,
	[PhoneNo] [varchar](20) NULL,
	[Disease] [varchar](100) NULL,
	[DoctorId] [varchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[PatientId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
================================================================================


create Procedure [46009517].[DeletePatient]

@PatientId varchar(10)

as 
begin 
Delete [46009517].Patient where PatientId=@PatientId
end
GO

=========================================================================

create Procedure [46009517].[InsertPatient]
(
@PatientId varchar(20),
@PatientName varchar(20),
@Age int,
@PWeight real,
@Gender varchar(20),
@PAddress varchar(100),
@PhoneNo varchar(20),
@Disease varchar(100),
@DoctorId varchar(20)) 
as 
begin 
insert into [46009517].Patient values(@PatientId,@PatientName,@Age,@PWeight,@Gender,@PAddress,@PhoneNo,@Disease,@DoctorId)
end
GO

============================================================================

create procedure [46009517].[ListPatient]
As
Begin
select * From [46009517].Patient
end

GO

================================================================================

create Procedure [46009517].[SelectPatient]
 (
 @PatientId varchar(20),
@PatientName varchar(20) output,
@Age int output,
@PWeight real output,
@Gender varchar(20) output,
@PAddress varchar(100) output,
@PhoneNo varchar(20) output,
@Disease varchar(100) output,
@DoctorId varchar(20) output) 
as 
begin 
select  @PatientName=PatientName, @Age=Age,@PWeight=PWeight,@Gender=Gender,@PAddress=PAddress,@PhoneNo=PhoneNo, @Disease=Disease, @DoctorID=DoctorID 
 from [46009517].Patient where PatientId= @PatientId 
end
GO

=====================================================================================

create Procedure [46009517].[UpdatePatient]
(
@PatientId varchar(20),
@PatientName varchar(20),
@Age int,
@PWeight real,
@Gender varchar(20),
@PAddress varchar(100),
@PhoneNo varchar(20),
@Disease varchar(100),
@DoctorId varchar(20)) 
as 
begin 
update [46009517].Patient set PatientName=@PatientName,Age=@Age,PWeight=@PWeight,Gender=@Gender,PAddress=@PAddress,PhoneNo=@PhoneNo,Disease=@Disease,DoctorId=@DoctorId where PatientId= @PatientId
end
GO
============================================================================

//InPatient Stored Procedure

create procedure [46009517].[Delete_InPatient]

@PatientId varchar(10)

as
begin
delete [46009517].InPatient where PatientId=@PatientId
end
GO
====================================================================

create procedure [46009517].[Insert_InPatient]
(
@PatientId varchar(10),
@RoomNo varchar(20),
@DoctorId varchar(20),
@AdmissionDate date,
@DischargeDate date,
@LabId varchar(20),
@Amount Real
)
as 
begin
insert into [46009517].InPatient values(@PatientId,@RoomNo,@DoctorId,@AdmissionDate,@DischargeDate,@LabId,@Amount)
end
GO

==========================================================================

create Procedure [46009517].[Select_InPatient]
(
@RoomNo varchar(20) output,
@DoctorId varchar(20) output,
@AdmissionDate date output,
@DischargeDate date output,
@LabId varchar(20) output,
@Amount Real output,
@PatientId varchar(10)) 
as 
begin 
Select @RoomNo=RoomNo,@DoctorId=DoctorId,@AdmissionDate=AdmissionDate,@DischargeDate=DischargeDate,@LabId=LabId,@Amount=Amount
from [46009517].InPatient where PatientId=@PatientId
end


GO
=========================================================================

create procedure [46009517].[Update_InPatient]
(
@PatientId varchar(10),
@RoomNo varchar(20),
@DoctorId varchar(20),
@AdmissionDate date,
@DischargeDate date,
@LabId varchar(20),
@Amount Real
)
as 
begin
update [46009517].InPatient set RoomNo=@RoomNo,DoctorId=@DoctorId,AdmissionDate=@AdmissionDate,DischargeDate=@DischargeDate,LabId=@LabId,Amount=@Amount where PatientId=@PatientId
end
GO

======================================================================
create procedure [46009517].[List_InPatient]
as
begin
select * from [46009517].Inpatient
end

GO
=============================================

create procedure [46009517].[Insert_InPatient]
(
@PatientId varchar(10),
@RoomNo varchar(20),
@DoctorId varchar(20),
@AdmissionDate date,
@DischargeDate date,
@LabId varchar(20),
@Amount Real
)
as 
begin
insert into [46009517].InPatient values(@PatientId,@RoomNo,@DoctorId,@AdmissionDate,@DischargeDate,@LabId,@Amount)
end
GO


============================================
create procedure [46009517].[GetDoctor]
as
 begin
 select * from [46009517].Doctor
 end
GO
===========================================
create procedure [46009517].[GetLab]
 As
Begin
select * From [46009517].Lab
end
GO
==========================
create procedure [46009517].[GetRoom]
 as
 begin
 select * from [46009517].RoomData
 end

GO
